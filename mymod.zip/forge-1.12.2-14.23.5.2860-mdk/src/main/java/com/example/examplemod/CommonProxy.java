package com.example.commonproxy;

public class CommonProxy {
public void registerItemRender(Item item, int meta, String id) {}
}
