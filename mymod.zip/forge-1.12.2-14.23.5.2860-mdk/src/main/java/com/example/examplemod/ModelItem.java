package com.example.modelitem;

public interface ModelItem {
public void registerModels();
}
