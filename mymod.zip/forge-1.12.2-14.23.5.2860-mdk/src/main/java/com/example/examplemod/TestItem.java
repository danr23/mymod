package com.example.testitem;

import com.example.modelitem.ModelItem;
import net.minecraft.item.Item;
import net.minecraft.creativetab.CreativeTabs;

public class TestItem extends Item implements ModelItem {
public TestItem(String name) {
setRegistryName(name);
setUnlocalizedName(name);
setCreativeTab(CreativeTabs.MATERIALS);
setMaxStackSize(32);
InitItems.ITEMS.add(this);
}
@Override
public void registerModels() {
ExampleMod.proxy.registerItemRender(this, 0, "inventory");
}
}
