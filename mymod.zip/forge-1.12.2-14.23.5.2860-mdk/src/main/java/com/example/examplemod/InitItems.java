package com.example.init;

import com.example.testitem.TestItem;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.item.Item;

public class InitItems {
public static final List<Item> ITEMS = new ArrayList<Item>();

public static final Item TEST_Item = new TestItem("test_item");
}
